/**
 * LinkedFollow Content Script
 * Runs on: https://www.linkedin.com/*
 */

(function () {
  "use strict";

  function isProfilePage() {
    return window.location.pathname.startsWith("/in/");
  }

  /**
   * Extract profile data using broad selectors + fallbacks.
   * LinkedIn changes its class names frequently, so we use multiple strategies.
   */
  function extractProfileData() {
    const data = {
      name: null,
      linkedin_url: null,
      company: null,
      role: null,
      location: null,
      profile_image: null,
    };

    // URL — always reliable
    data.linkedin_url = "https://www.linkedin.com" +
      window.location.pathname.replace(/\/$/, "") + "/";

    // --- NAME ---
    // Strategy 1: any h1 on the page (LinkedIn always has exactly one)
    const h1 = document.querySelector("h1");
    if (h1 && h1.textContent.trim().length > 1) {
      data.name = h1.textContent.trim();
    }
    // Strategy 2: page title "Name | LinkedIn"
    if (!data.name && document.title) {
      const titleName = document.title.split("|")[0].trim();
      if (titleName && titleName.length > 1 && titleName !== "LinkedIn") {
        data.name = titleName;
      }
    }
    // Strategy 3: og:title meta tag
    if (!data.name) {
      const ogTitle = document.querySelector('meta[property="og:title"]');
      if (ogTitle) {
        data.name = ogTitle.getAttribute("content")?.split("|")[0]?.trim() || null;
      }
    }

    // --- ROLE / HEADLINE ---
    // LinkedIn renders the headline in a div right after h1, often with class containing "text-body"
    const allTextBody = document.querySelectorAll('[class*="text-body-medium"]');
    for (const el of allTextBody) {
      const text = el.textContent.trim();
      if (text && text.length > 3 && text.length < 300 && !text.includes("connections")) {
        data.role = text;
        break;
      }
    }

    // --- LOCATION ---
    const allSmallText = document.querySelectorAll('[class*="text-body-small"]');
    for (const el of allSmallText) {
      const text = el.textContent.trim();
      // Location is usually a short line with a city/country
      if (text && text.length > 2 && text.length < 100 &&
          !text.includes("connections") && !text.includes("followers") &&
          !text.includes("Contact info") && !text.includes("·")) {
        data.location = text;
        break;
      }
    }

    // --- PROFILE IMAGE ---
    // Find img inside the top section — profile photos have specific patterns
    const imgs = document.querySelectorAll("img");
    for (const img of imgs) {
      const src = img.src || "";
      const alt = img.alt || "";
      // LinkedIn profile images come from licdn.com and have profile-related URLs
      if (src && !src.startsWith("data:") &&
          (src.includes("licdn.com") || src.includes("linkedin.com")) &&
          (src.includes("profile") || src.includes("shrink") || alt === data.name)) {
        data.profile_image = src;
        break;
      }
    }

    return data;
  }

  function showToast(message, type = "success") {
    const existing = document.getElementById("lf-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.id = "lf-toast";
    toast.textContent = message;
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      background: ${type === "success" ? "#2563eb" : "#dc2626"};
      color: white;
      padding: 12px 18px;
      border-radius: 8px;
      font-size: 14px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-weight: 500;
      box-shadow: 0 4px 16px rgba(0,0,0,0.2);
      opacity: 1;
      transition: opacity 0.4s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 400);
    }, 3000);
  }

  function captureCurrentProfile(callback, actionStatus, extraData) {
    if (!isProfilePage()) {
      const err = { success: false, error: "Not on a LinkedIn profile page (/in/...)" };
      if (callback) callback(err);
      return;
    }

    const profileData = extractProfileData();
    console.log("[LinkedFollow] Extracted profile data:", JSON.stringify(profileData, null, 2));

    if (!profileData.name) {
      const err = { success: false, error: "Could not read profile name" };
      showToast("⚠ Could not read profile name", "error");
      if (callback) callback(err);
      return;
    }

    // Merge action status and timestamps into payload
    if (actionStatus) {
      profileData.status = actionStatus;
    }
    if (extraData) {
      Object.assign(profileData, extraData);
    }

    chrome.runtime.sendMessage(
      { type: "SAVE_CONTACT", payload: profileData },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error("[LinkedFollow]", chrome.runtime.lastError.message);
          if (callback) callback({ success: false, error: chrome.runtime.lastError.message });
          return;
        }
        if (response?.success) {
          const label = actionStatus === "Pending" ? "⏳ Connection request saved"
            : actionStatus === "Messaged" ? "💬 Message tracked"
            : "✓ Contact saved to LinkedFollow";
          showToast(label);
        } else {
          console.error("[LinkedFollow] Save failed:", response?.error);
          showToast("✗ " + (response?.error || "Save failed"), "error");
        }
        if (callback) callback(response);
      }
    );
  }

  // Auto-capture on action button clicks — detect which action was taken
  document.addEventListener("click", (event) => {
    let el = event.target;
    for (let i = 0; i < 8; i++) {
      if (!el || el === document.body) break;
      const tag = (el.tagName || "").toLowerCase();
      const ariaLabel = (el.getAttribute?.("aria-label") || "").toLowerCase();
      const text = (el.innerText || "").trim().toLowerCase().split("\n")[0];

      const isConnect = ariaLabel.includes("connect") || text === "connect";
      const isMessage = ariaLabel.includes("message") || text === "message";
      const isFollow  = ariaLabel.includes("follow")  || text === "follow";

      if ((tag === "button" || tag === "a") && (isConnect || isMessage || isFollow)) {
        // Determine the status to save based on action
        let actionStatus = "Pending";
        let extraData = {};
        const now = new Date().toISOString();

        if (isConnect) {
          actionStatus = "Pending";  // pending until they accept
          extraData = { connection_sent_at: now };
        } else if (isMessage) {
          actionStatus = "Messaged";
          extraData = { last_messaged_at: now };
        } else if (isFollow) {
          actionStatus = "Connected";
        }

        console.log("[LinkedFollow] Action button clicked:", text || ariaLabel, "→", actionStatus);
        setTimeout(() => captureCurrentProfile(null, actionStatus, extraData), 800);
        break;
      }
      el = el.parentElement;
    }
  }, true);

  // Listen for manual capture from popup
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "CAPTURE_NOW") {
      // Manual save defaults to Connected status
      captureCurrentProfile(sendResponse, "Connected", { connection_sent_at: new Date().toISOString() });
      return true;
    }
  });

  console.log("[LinkedFollow] Active on", window.location.pathname);
})();
