/**
 * LinkedFollow Popup Script
 *
 * Handles:
 * - Showing login vs logged-in state
 * - Saving credentials to chrome.storage
 * - Logging out
 */

const APP_URL = "https://linkedin-followup-tracker.vercel.app"; // production

document.addEventListener("DOMContentLoaded", async () => {
  const loginView = document.getElementById("login-view");
  const loggedInView = document.getElementById("logged-in-view");
  const loginBtn = document.getElementById("login-btn");
  const logoutBtn = document.getElementById("logout-btn");
  const captureBtn = document.getElementById("capture-btn");
  const captureMessageEl = document.getElementById("capture-message");
  const messageEl = document.getElementById("message");
  const userEmailEl = document.getElementById("user-email");
  const dashboardLink = document.getElementById("dashboard-link");

  // Check if already authenticated
  const auth = await getAuth();

  if (auth.userId && auth.apiSecret) {
    showLoggedIn(auth);
  } else {
    showLogin();
  }

  // Connect button — save credentials directly, no ping needed
  loginBtn.addEventListener("click", async () => {
    const apiUrl = document.getElementById("api-url").value.trim().replace(/\/$/, "");
    const apiSecret = document.getElementById("api-secret").value.trim();
    const userId = document.getElementById("user-id").value.trim();

    if (!apiUrl || !apiSecret || !userId) {
      showMessage("All fields are required.", "error");
      return;
    }

    // Basic UUID format check for user ID
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(userId)) {
      showMessage("User ID looks wrong — copy it exactly from Dashboard → Extension Setup.", "error");
      return;
    }

    // Save to storage immediately — no network ping required
    await new Promise((resolve) => {
      chrome.storage.local.set(
        {
          lf_api_url: apiUrl,
          lf_api_secret: apiSecret,
          lf_user_id: userId,
        },
        resolve
      );
    });

    // Notify background service worker
    chrome.runtime.sendMessage({
      type: "SET_AUTH",
      token: apiSecret,
      userId,
    });

    showLoggedIn({ userId, apiUrl });
    showMessage("Connected! Visit a LinkedIn profile and click Connect to test.", "success");
  });

  // Manual capture button — sends message to content script
  captureBtn.addEventListener("click", async () => {
    captureBtn.disabled = true;
    captureBtn.textContent = "Saving…";
    showCaptureMessage("", "");

    // Get the active LinkedIn tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.url || !tab.url.includes("linkedin.com/in/")) {
        showCaptureMessage("Go to a LinkedIn profile page first (/in/...)", "error");
        captureBtn.disabled = false;
        captureBtn.textContent = "💾 Save This Profile Now";
        return;
      }

      chrome.tabs.sendMessage(tab.id, { type: "CAPTURE_NOW" }, (response) => {
        captureBtn.disabled = false;
        captureBtn.textContent = "💾 Save This Profile Now";
        if (chrome.runtime.lastError) {
          showCaptureMessage("Error: " + chrome.runtime.lastError.message, "error");
          return;
        }
        if (response?.success) {
          showCaptureMessage("✓ Contact saved!", "success");
        } else {
          showCaptureMessage("✗ " + (response?.error || "Failed"), "error");
        }
      });
    });
  });

  // Sign out
  logoutBtn.addEventListener("click", async () => {
    await new Promise((resolve) => {
      chrome.storage.local.remove(
        ["lf_api_url", "lf_api_secret", "lf_user_id"],
        resolve
      );
    });
    chrome.runtime.sendMessage({ type: "CLEAR_AUTH" });
    showLogin();
  });

  function showLoggedIn(auth) {
    loginView.style.display = "none";
    loggedInView.style.display = "block";

    const displayId = auth.userId
      ? auth.userId.slice(0, 8) + "…"
      : "Connected";
    userEmailEl.textContent = `User: ${displayId}`;

    const base = auth.apiUrl || APP_URL;
    dashboardLink.href = `${base}/dashboard`;
  }

  function showLogin() {
    loginView.style.display = "block";
    loggedInView.style.display = "none";
    clearMessage();
  }

  function showMessage(text, type) {
    messageEl.textContent = text;
    messageEl.className = `message ${type}`;
  }

  function clearMessage() {
    messageEl.className = "message";
    messageEl.textContent = "";
  }

  function showCaptureMessage(text, type) {
    captureMessageEl.textContent = text;
    captureMessageEl.className = type ? `message ${type}` : "message";
  }
});

/**
 * Get auth data from chrome.storage
 */
function getAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      ["lf_api_url", "lf_api_secret", "lf_user_id"],
      (result) => {
        resolve({
          apiUrl: result.lf_api_url || null,
          apiSecret: result.lf_api_secret || null,
          userId: result.lf_user_id || null,
        });
      }
    );
  });
}
