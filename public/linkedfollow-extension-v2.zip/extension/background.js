/**
 * LinkedFollow Background Service Worker
 *
 * Handles:
 * 1. Receiving SAVE_CONTACT messages from content.js
 * 2. Retrieving auth from chrome.storage
 * 3. Posting contact data to the Next.js API
 */

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "SAVE_CONTACT") {
    handleSaveContact(message.payload).then(sendResponse);
    return true; // keep channel open for async response
  }

  if (message.type === "SET_AUTH") {
    // Called by popup after user connects
    chrome.storage.local.set({
      lf_api_secret: message.token,
      lf_user_id: message.userId,
    });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "CLEAR_AUTH") {
    chrome.storage.local.remove(["lf_api_url", "lf_api_secret", "lf_user_id"]);
    sendResponse({ ok: true });
    return true;
  }
});

/**
 * Retrieve all stored auth values from chrome.storage.local
 */
function getStoredAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      ["lf_api_url", "lf_api_secret", "lf_user_id"],
      (result) => {
        resolve({
          apiUrl: result.lf_api_url || "https://linkedin-followup-tracker.vercel.app",
          apiSecret: result.lf_api_secret || null,
          userId: result.lf_user_id || null,
        });
      }
    );
  });
}

/**
 * Save a contact by calling the Next.js API.
 */
async function handleSaveContact(payload) {
  try {
    const auth = await getStoredAuth();

    if (!auth.userId || !auth.apiSecret) {
      console.warn("[LinkedFollow] Not authenticated — open the extension popup and connect.");
      return { success: false, error: "Not authenticated" };
    }

    const body = {
      ...payload,
      user_id: auth.userId,
    };

    console.log("[LinkedFollow] Saving contact to", auth.apiUrl, body);

    const response = await fetch(`${auth.apiUrl}/api/contact/save`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Extension-Api-Secret": auth.apiSecret,
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("[LinkedFollow] API error:", data);
      return { success: false, error: data.error };
    }

    console.log("[LinkedFollow] Contact saved:", data);
    return { success: true, data };
  } catch (err) {
    console.error("[LinkedFollow] Network error:", err);
    return { success: false, error: "Network error" };
  }
}
